<?php 

	session_start();

 ?>

 <!DOCTYPE html>
 <html>	
	<head>
	</head>

	<body>
		

		<header>
			<nav>
				<img class="main-logo" src="https://img.icons8.com/plasticine/80/000000/delete-chat--v2.png"/>
				<a class="homepage" href="index.php">forum.ppl</a>

			</nav>

			<?php 

			if(isset($_SESSION['username'])){
				
				echo "<form action='actions/logout-action.php'>
					<button type='submit
					' name='logout-btn' class='logout-btn'>LogOut</button>
					</form>";	
			}

			?>



		</header>

		<?php 

			if(isset($_SESSION['username'])){

			}

			else{

				header("Location: index.php?error=signIn");
				exit();			}

		 ?>
	</body>
 </html>