<?php

require 'header.php';

$uniqid = $_GET['uniqid'];
$topic = $_GET['topic'];
$author = $_GET['author'];
$content = $_GET['content'];

$conn = mysqli_connect('localhost', 'root', 'pass', 'forumlogin');

?>

<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>My Forum</title>
	<link rel="stylesheet" href="commentstyle.css">
	<script src="https://kit.fontawesome.com/8df63a29e3.js" crossorigin="anonymous"></script>
</head>
<body>
	<div class="container">
		<div class="post" id="post-<?= $uniqid ?>">
			<h2 class="post-topic"><?=$topic ?></h2>
			<h4 class="post-author">@<?=$author?></h4>
			<p class="post-content"><?=$content ?></p>
		</div>
	</div>

	<div class="comments">
		

	</div>

	<div class="gap"></div>

	<div class="form">
		<form id="cmt-form" action="posts/new-comment.php" method="post" class="comment">
			<input class="cmt-input" type="text" name="content" placeholder="Comment..." required>
			<button name="cmt-submit" id="cmt-btn" type="button">Add Comment</button>
		</form>
	</div>
	
	<!-- <div class="edit-form">
		<form action="" id="edit-form" method="post">
			<input id="edit-cmt" type="text" name="comment" placeholder="New comment..." required>
			<button name="edit-submit" type="button" id="edit-submit">Submit Changes</button>
		</form>
	</div> -->

	<?php 

		echo "<script type='text/javascript'>var uniqid = '".$uniqid."'; var session_un='".$_SESSION['username']."'; var usertype='".$_SESSION['usertype']."';</script>";
		echo "<script type='text/javascript' src='cscript.js'></script>";
	 ?>
	
</body>
</html>