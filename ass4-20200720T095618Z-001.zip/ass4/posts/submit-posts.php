<?php 

$servername = "localhost";
$dbusername = "root";
$dbpassword = "pass";
$dbname = "forumlogin";

$author = $_POST['author'];
$topic = $_POST['topic'];
$content = $_POST['content'];

$conn = mysqli_connect($servername, $dbusername, $dbpassword, $dbname);

if(empty($author) or empty($topic) or empty($content)){

	header("Location: ../index.php?error=emptyFields");
	exit();
}

$query = "INSERT INTO posts (author, topic, content) VALUES ('$author', '$topic', '$content')";

$result = mysqli_query($conn, $query);

if(!($result)){

	header("Location: ../index.php?error=sqlError");
	exit();	

} 