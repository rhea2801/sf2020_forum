<?php 

	
	
	$servername = "localhost";
	$dbusername = "root";
	$dbpassword = "pass";
	$dbname = "forumlogin";

	$conn = mysqli_connect($servername, $dbusername, $dbpassword, $dbname);

	$query = "SELECT * FROM posts ORDER BY uniqid DESC";
	$result = mysqli_query($conn, $query);

	$posts = mysqli_fetch_all($result, MYSQLI_ASSOC);

	echo JSON_encode($posts);