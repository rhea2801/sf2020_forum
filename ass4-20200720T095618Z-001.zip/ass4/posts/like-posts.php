<?php 

$servername = "localhost";
$dbusername = "root";
$dbpassword = "pass";
$dbname = "forumlogin";

$conn = mysqli_connect($servername, $dbusername, $dbpassword, $dbname);

$post_id = $_GET['post_id'];
$user_id = $_GET['username'];
$action = $_GET['action'];

switch ($action) {
	case 'like':
		$status = 1;
		break;
	case 'dislike':
		$status=-1;
		break;
	case 'unlike':
		$status=0;
		break;
}

echo $status;

$query = "SELECT * FROM likes WHERE post_id='$post_id' AND user_id='$user_id'";

$result = mysqli_query($conn, $query);

if(mysqli_num_rows($result) != 0){

	echo "found";

	$query_update = "UPDATE likes SET like_status='$status' WHERE post_id='$post_id' AND user_id='$user_id'";

	$result_update = mysqli_query($conn, $query_update);

}else{

	echo "not found";

	$query_insert = "INSERT INTO likes (post_id, user_id, like_status) VALUES ('$post_id', '$user_id', '$status')";

	$result_insert = mysqli_query($conn, $query_insert);
}
