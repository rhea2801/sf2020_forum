<?php 

if(isset($_POST['post-submit'])){

	require "dbh-posts.php";

	$author = $_POST['username'];
	$topic = $_POST['topic'];
	$content = $_POST['content'];
	
	$sql = "INSERT INTO posts (topic, content, author) VALUES (?,?,?)";

	$stmt = mysqli_stmt_init($conn);

	if(!mysqli_stmt_prepare($stmt, $sql)){

		//connection lost 

		header("Location: ../index.php?error=sqlFailed");
		exit();

	}

	else{

		mysqli_stmt_bind_param($stmt, "sss", $topic, $content, $author);

		mysqli_stmt_execute($stmt);

		header("Location: ../index.php");

		exit();

	}



}

else{

	header("Location: ../index.php?error=noSubmit");
	exit();
}