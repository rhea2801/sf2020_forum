<?php 

$servername = "localhost";
$dbusername = "root";
$dbpassword = "pass";
$dbname = "forumlogin";

$conn = mysqli_connect($servername, $dbusername, $dbpassword, $dbname);

if(!$conn){

	die("didnt connect".mysqli_connect_error());
}