<?php 

if(isset($_POST['reg-submit'])){

	require 'dbh-action.php';

	$fname = $_POST['fname'];
	$lname = $_POST['lname'];
	$username = $_POST['username'];
	$pwd = $_POST['pwd'];
	$email = $_POST['email'];
	$pwdConfirm = $_POST['pwdConfirm'];

	$dobPrev = $_POST['dob'];
	$dob = date('y-m-d', strtotime($dobPrev));

	$gender = $_POST['gender'];
	$usertype = $_POST['usertype'];


// error handlers section

	// empty fields

	if(empty($fname) or empty($lname) or empty($username) or empty($pwd) or empty($email) or empty($pwdConfirm) or empty($dob) or empty($gender) or empty($usertype)){

		header("Location: ../reg.php?error=emptyfields&fname=".$fname."&lname=".$lname."&lname=".$lname."&username=".$username."&email=".$email);
		exit();

	}

	//invalid email & username

	else if(!filter_var($email, FILTER_VALIDATE_EMAIL)){

		//if both invalid, then URL changes

		if(!preg_match("/^[a-zA-Z0-9]*$/", $username)){

			header("Location: ../reg.php?error=invalidEmailandUsername&fname=".$fname."&lname=".$lname."&lname=".$lname);
			exit();

		}

		else{

			header("Location: ../reg.php?error=invalidEmail&fname=".$fname."&lname=".$lname."&lname=".$lname."&username=".$username);
			exit();

		}

	}

	else if(!preg_match("/^[a-zA-Z0-9]*$/", $username)){

		header("Location: ../reg.php?error=invalidUsername&fname=".$fname."&lname=".$lname."&lname=".$lname."&email=".$email);
		exit();
	}

	// passwords do not match

	else if($pwd !== $pwdConfirm){

		 header("Location: ../reg.php?error=pwdError&fname=".$fname."&lname=".$lname."&lname=".$lname."&username=".$username."&email=".$email);
		exit();

	}


	// username or email taken

	else{

		$sql = "SELECT username FROM users WHERE username=?";
		$stmt = mysqli_stmt_init($conn);

		// if sql connection failed

		if(!mysqli_stmt_prepare($stmt, $sql)){

			header("Location: ../reg.php?error=sqlFailed1");
			exit();

		}

		else{

			// bind parameters to prepared statement 

			mysqli_stmt_bind_param($stmt, "s", $username);

			mysqli_stmt_execute($stmt);

			// is there a match

			mysqli_stmt_store_result($stmt);

			$match = mysqli_stmt_num_rows($stmt);

			//match exists

			if($match){

				header("Location: ../reg.php?error=usernameTaken");
				exit();

			}

			else{

				$sql = "INSERT INTO users (fname, lname, username, email, pwd, dob, gender, usertype) VALUES (?, ?, ?, ?, ?, ?, ?, ?)";

				$stmt = mysqli_stmt_init($conn);

				if(!mysqli_stmt_prepare($stmt, $sql)){

					//connection lost 

					header("Location: ../reg.php?error=sqlFailed2");
					exit();

				}

				else{

					//bind parameters & hash pwd

					$hashedPwd = password_hash($pwd, PASSWORD_DEFAULT);

					mysqli_stmt_bind_param($stmt, "ssssssss", $fname, $lname, $username, $email, $hashedPwd, $dob, $gender, $usertype);

					mysqli_stmt_execute($stmt);

					// URL shows signup is success

					header("Location: ../reg.php?signUp=success");

					echo $dob;

					exit();


				}

			}

		}

	}

	//close connections

	mysqli_stmt_close($stmt);

	mysqli_close($conn);

}

// if user accessed page without going through signup button, redirect them to reg. page

else{

	header("Location: ../reg.php?accessDenied");
	exit();

}

