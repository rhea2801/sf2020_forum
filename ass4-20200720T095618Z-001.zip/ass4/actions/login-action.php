<?php 

if(isset($_POST['login-submit'])){

	require 'dbh-action.php';

	$username = $_POST['username'];
	$pwd = $_POST['pwd'];
	$usertype = $_POST['usertype'];

	//any field empty

	if(empty($pwd) or empty($username) or empty($usertype)){

		header("Location: ../index.php?error=emptyFields");
		exit();
	}

	// check if username exists in db

	else{

		$sql = "SELECT * FROM users WHERE username=?";
		$stmt = mysqli_stmt_init($conn);

		if(!mysqli_stmt_prepare($stmt, $sql)){

			header("Location: ../index.php?error=sqlError0");
			exit();
		}

		else{

			mysqli_stmt_bind_param($stmt, "s", $username);
			mysqli_stmt_execute($stmt);

			$match = mysqli_stmt_get_result($stmt);
			$num = mysqli_fetch_assoc($match);

			// username doesnt exist

			if($num==0){

				header("Location: ../index.php?error=userDNE");
				exit();
			}


			else{

				//pwd is correct or not

				$pwdMatch = password_verify($pwd, $num['pwd']);

				if(!$pwdMatch){

					header("Location: ../index.php?error=wrongPwd");
					exit();
				}

				else{

					//user or admin type matches

					$usertypeMatch = $num['usertype'];

					if(!($usertype==$usertypeMatch)){

						header("Location: ../index.php?error=wrongUsertype");
						exit();
					}

					else{

						session_start();
						$_SESSION['username'] = $num['username'];
						$_SESSION['fname'] = $num['fname'];
						$_SESSION['uniqid'] = $num['uniqid'];
						$_SESSION['usertype'] = $num['usertype'];

						header("Location: ../index.php?login=success");
						exit();
						
					}
				}
			}
		}
	}

}

// accessed without login

else{

	header("Location: ../index.php?error=accessDenied");
	exit();
}