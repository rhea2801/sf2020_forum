<?php 

require 'header.php';

//echo "hello";

echo "
<div class='hello-user'>
	<p>Hi there, ".$_SESSION['fname'];

if($_SESSION['usertype']=="user"){

	echo" &#127773</p></div>";

}
else if($_SESSION['usertype']=="admin"){

	echo" &#127770</p></div>";
}


?>

<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>Forum Homepage</title>
	<script src="https://kit.fontawesome.com/8df63a29e3.js" crossorigin="anonymous"></script>
	<link rel="stylesheet" href="homepagestyle.css">

</head>
<body>
	<div>
		<button id="btn">Create New Post</button>
	</div>

	<div id="posts">
		<div class="post">
			<h2>This is the topic.</h2>
			<h4>username</h4>
			<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Harum adipisci eum, repellendus soluta. Molestias, dolore, neque totam quisquam, inventore officiis magni provident ducimus quos unde eaque veritatis. Magni, nihil, sequi!</p>
			<div class="icondiv"><span>Like</span><i class="post-icon far fa-thumbs-up"></i></div>
			<div class="icondiv"><span>Dislike</span><i class="post-icon far fa-thumbs-down"></i></div>
			<div class="icondiv"><span>Comment</span><i class="post-icon fas fa-comments"></i></div>

		</div>
	</div>
	
	<div class="form">
		<form id="new-post" action="posts/submit-posts.php" method="post">

			<!--  <input type="text" name="author" class="form-username" placeholder="Username..." required> -->

			<input class="form-topic" name="topic" type="text" placeholder="Topic..." required>

			<input class="form-content" name="content" type="text" placeholder="Content..." required>

			<button id="discard" type="button">Discard</button>

			<button id="submit" type="button" name="post-submit">Submit</button>

		</form>
	</div>

	<div class="edit-form">
		<form id="edit-post" action="posts/edit-posts.php" method="post">

			<input class="edit-form-topic" name="topic" type="text" placeholder="Topic..." required>

			<input class="edit-form-content" name="content" type="text" placeholder="Content..." required>

			<input class="edit-form-uniqid" type="hidden" name="uniqid">

			<button id="edit-discard" type="button">Discard</button>

			<button id="edit-submit" type="button" name="post-submit">Submit</button>

		</form>
	</div>

<?php 
	
	echo "<script type='text/javascript'>var session_un = '".$_SESSION['username']."'; var usertype='".$_SESSION['usertype']."';</script>";

 ?>	
<script src="script.js"></script>

	
</body>
</html>