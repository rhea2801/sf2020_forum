var tgl = document.querySelector("#tgl");
var tglDiv = document.querySelector(".toggle");
var tglContent = document.querySelector(".toggle-content");

// adding hover functions

tglDiv.addEventListener("mouseover", incHeight);
tglDiv.addEventListener("mouseout", decHeight);

function incHeight(){

	tglDiv.style.height = "70px";
}

function decHeight(){

	tglDiv.style.height = "40px";
}

//adding onclick functions

tgl.addEventListener("click", showReg);

function showReg(){

	tgl.style.transform = "rotate(180deg)";
	tgl.removeEventListener("click", showReg);
	tgl.addEventListener("click", removeReg);

	tglDiv.removeEventListener("mouseover", incHeight);
	tglDiv.removeEventListener("mouseout", decHeight);
	
	tglDiv.style.height = "100%";

	tglContent.style.visibility = "visible";

}

function removeReg(){

	tglContent.style.visibility = "hidden";

	tgl.style.transform = "";
	tgl.addEventListener("click", showReg);
	tgl.removeEventListener("click", removeReg);

	tglDiv.style.height = "40px";

	tglDiv.addEventListener("mouseover", incHeight);
	tglDiv.addEventListener("mouseout", decHeight);

	
}