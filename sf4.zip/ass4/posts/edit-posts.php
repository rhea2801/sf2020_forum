<?php 

//$conn = mysqli_connect('localhost', 'root', 'pass', 'forumlogin');
require 'dbh-posts.php';

$uniqid = $_POST['uniqid'];
$topic = $_POST['topic'];
$content =  $_POST['content'];

$query = "UPDATE posts SET topic = '$topic', content = '$content' WHERE uniqid='$uniqid'";

$result = mysqli_query($conn, $query);

if(!$result){

	header("Location: ../index.php?error=mysqlError");
	exit();
}

