<?php 

/*$servername = "localhost";
$dbusername = "root";
$dbpassword = "pass";
$dbname = "forumlogin";

$conn = mysqli_connect($servername, $dbusername, $dbpassword, $dbname);
*/

require 'dbh-posts.php';

// if particular post has to be updated

if(isset($_GET['post_id'])){

	$post_id = $_GET['post_id'];

	$query = "SELECT * FROM likes WHERE post_id = '$post_id'";
	$result = mysqli_query($conn, $query);

	$posts = mysqli_fetch_all($result, MYSQLI_ASSOC);

	echo JSON_encode($posts);

}

