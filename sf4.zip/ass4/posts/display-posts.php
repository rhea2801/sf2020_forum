<?php 	
	
require 'dbh-posts.php';

$query = "SELECT * FROM posts ORDER BY uniqid DESC";
$result = mysqli_query($conn, $query);

$posts = mysqli_fetch_all($result, MYSQLI_ASSOC);

echo JSON_encode($posts);