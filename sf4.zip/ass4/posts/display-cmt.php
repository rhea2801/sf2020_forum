<?php 

//require "../header.php";

$uniqid = $_POST['uniqid'];

//$conn = mysqli_connect('localhost', 'root', 'pass', 'forumlogin');
require 'dbh-posts.php';

$query = "SELECT * FROM comments WHERE post_id='$uniqid' ORDER BY cmt_uniqid DESC";

$result = mysqli_query($conn, $query);

$comments = mysqli_fetch_all($result, MYSQLI_ASSOC);

echo JSON_encode($comments);