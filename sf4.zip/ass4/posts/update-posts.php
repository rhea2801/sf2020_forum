<?php 

//$conn = mysqli_connect('localhost', 'root', 'pass', 'forumlogin');
require 'dbh-posts.php';

$uniqid = $_POST['uniqid'];

$query = "SELECT * FROM posts WHERE uniqid = '$uniqid'";

$result = mysqli_query($conn, $query);

$post = mysqli_fetch_all($result, MYSQLI_ASSOC);

echo JSON_encode($post);