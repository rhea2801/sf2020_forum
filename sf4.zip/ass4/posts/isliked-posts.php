<?php

$post_id = $_POST['uniqid'];
$user_id = $_POST['username'];

//$conn = mysqli_connect('localhost', 'root', 'pass', 'forumlogin');
require 'dbh-posts.php';

$query = "SELECT like_status FROM likes WHERE post_id='$post_id' AND user_id = '$user_id'";

$result = mysqli_query($conn, $query);

if (mysqli_num_rows($result) > 0){

    while($row = mysqli_fetch_assoc($result)) {
       echo $row["like_status"];
    }

}

else {
    echo "0";
}