<?php 

//$conn = mysqli_connect('localhost', 'root', 'pass', 'forumlogin');

require 'dbh-posts.php';

$cmt_uniqid = $_POST['cmt_uniqid'];

$query = "DELETE FROM comments WHERE cmt_uniqid = '$cmt_uniqid'";

$result = mysqli_query($conn, $query);

if(!$result){

	header("Location: ../index.php?error=sqlError");
	exit();
}