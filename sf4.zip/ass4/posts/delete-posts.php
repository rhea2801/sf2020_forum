<?php 

//$conn = mysqli_connect('localhost', 'root', 'pass', 'forumlogin');

require 'dbh-posts.php';

$uniqid = $_POST['uniqid'];

$query = "DELETE FROM posts WHERE uniqid = '$uniqid'";

$result = mysqli_query($conn, $query);

if(!$result){

	header("Location: ../index.php?error=sqlError");
	exit();
}