<?php 

require "../header.php";
//require "../comment.php";

$commenter = $_POST['commenter'];
$uniqid = $_POST['uniqid'];
$comment = $_POST['comment'];

//$conn = mysqli_connect('localhost', 'root', 'pass', 'forumlogin');
require 'dbh-posts.php';

$query = "INSERT INTO comments (post_id, commenter, comment) VALUES ('$uniqid', '$commenter', '$comment')";

if(!mysqli_query($conn, $query)){

	header("Location: ../index.php?error=sqlError");
	exit();
}