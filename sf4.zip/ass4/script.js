
var createBtn = document.querySelector("#btn");
createBtn.addEventListener("click", createPost);

var posts = document.querySelector("#posts");
var formDiv = document.querySelector(".form");

var submit = document.querySelector("#submit");
var discard = document.querySelector("#discard");

var bodyDiv = document.querySelector("body");

discard.addEventListener("click", discardPost);
submit.addEventListener("click", submitPost);

window.onload=displayAllPosts();

function createPost(){

	formDiv.style.visibility = "visible";
	
}

function discardPost(){

	document.querySelector(".form-topic").value = "";
	document.querySelector(".form-content").value = "";
	//document.querySelector(".form-username").value = "";
	formDiv.style.visibility = "hidden";
	
}


function submitPost(){

	if(document.querySelector(".form-topic").value=="" || document.querySelector(".form-content").value==""){

		alert("Please fill out all fields");
		return;
	}


	var author = session_un;
	var topic = document.querySelector(".form-topic").value;
	var content = document.querySelector(".form-content").value;

	
	var params = "author="+author+"&topic="+topic+"&content="+content;

	var xhr = new XMLHttpRequest();
	xhr.open("POST", "posts/submit-posts.php", true);
	xhr.setRequestHeader('Content-type', 'application/x-www-form-urlencoded');

	xhr.send(params);

	setTimeout(newPost, 100);
	discardPost();


}

function displayAllPosts(){

	var xhr = new XMLHttpRequest();
	xhr.open('GET', 'posts/display-posts.php', true);

	xhr.onload = function(){

		if(this.status == 200){

			var posts = JSON.parse(this.responseText);

			for(var i = posts.length-1; i>-1; i--){

				displayPosts(posts[i].author, posts[i].topic, posts[i].content, posts[i].likes, posts[i].dislikes, posts[i].comments, posts[i].uniqid);

				updateComments(posts[i].uniqid);
			}

			
		}

	}

	xhr.send();

}



function newPost(){

	var xhr = new XMLHttpRequest();
	xhr.open('GET', 'posts/display-posts.php', true);

	xhr.onload = function(){

		if(this.status == 200){

			var posts = JSON.parse(this.responseText);

			displayPosts(posts[0].author, posts[0].topic, posts[0].content, posts[0].likes, posts[0].dislikes, posts[0].comments, posts[0].uniqid);

			updateComments(posts[0].uniqid);

			
		}

	}

	xhr.send();

}

function displayPosts(author, topic, content, likes, dislikes, comments, uniqid){

	// making parent div and child divs

	var postDiv = document.createElement("div");
	postDiv.id = "post-"+uniqid;
	postDiv.className = "post";

	var topicDiv = document.createElement("h2");
	topicDiv.id = "topic-"+uniqid;
	topicDiv.className = "topic";
	topicDiv.innerHTML = topic;

	var authorDiv = document.createElement("h4");
	authorDiv.id = "author-"+uniqid;
	authorDiv.className = "author";
	authorDiv.innerHTML = "by: @"+author;

	var contentDiv = document.createElement("p");
	contentDiv.id = "content-"+uniqid;
	contentDiv.className = "content";
	contentDiv.innerHTML = content;

	// making the 3 icons & counts for each

	var likesDiv = document.createElement("div");
	var dislikesDiv = document.createElement("div");
	var commentsDiv = document.createElement("div");

	likesDiv.className = "icondiv";
	dislikesDiv.className = "icondiv";
	commentsDiv.className = "icondiv";

	var likesIcon = document.createElement("i");
	var dislikesIcon = document.createElement("i");
	var commentsIcon = document.createElement("i");


	likesIcon.className = "like-icon post-icon far fa-thumbs-up";
	dislikesIcon.className = "dislike-icon post-icon far fa-thumbs-down";
	commentsIcon.className = "comment-icon post-icon fas fa-comments";

	likesIcon.id="likes-"+uniqid;
	dislikesIcon.id="dislikes-"+uniqid;
	commentsIcon.id="comments-"+uniqid;

	likesIcon.setAttribute("data-like", uniqid);
	dislikesIcon.setAttribute("data-dislike", uniqid);
	commentsIcon.setAttribute("data-comment", uniqid);

	var likesSpan = document.createElement("span");
	var dislikesSpan = document.createElement("span");
	var commentsSpan = document.createElement("span");

	likesSpan.innerHTML = "Like ";
	dislikesSpan.innerHTML = "Dislike ";
	commentsSpan.innerHTML = "Comment ";

	var likesCount = document.createElement("span");
	var dislikesCount = document.createElement("span");
	var commentsCount = document.createElement("span");

	likesCount.id="likes-count-"+uniqid;
	dislikesCount.id="dislikes-count-"+uniqid;
	commentsCount.id="comments-count-"+uniqid;

	likesCount.innerHTML = likes;
	dislikesCount.innerHTML = dislikes;
	commentsCount.innerHTML = comments;

	// making necessary appends

	likesDiv.append(likesIcon);
	likesDiv.append(likesSpan);
	likesDiv.append(likesCount);

	dislikesDiv.append(dislikesIcon);
	dislikesDiv.append(dislikesSpan);
	dislikesDiv.append(dislikesCount);

	commentsDiv.append(commentsIcon);
	commentsDiv.append(commentsSpan);
	commentsDiv.append(commentsCount);

	postDiv.append(topicDiv);

//edit and delete functions are only for if it is your post or if you are admin

	if(usertype=="admin" || author==session_un){

		var editBtn = document.createElement("i");
		var deleteBtn = document.createElement("i");

		editBtn.className="edit-btn far fa-edit";
		deleteBtn.className="delete-btn far fa-trash-alt";

		editBtn.addEventListener("click", function(){

			showEditForm(uniqid);
		})

		deleteBtn.addEventListener("click", function(){

			deletePost(uniqid);
		})

		postDiv.append(deleteBtn);
		postDiv.append(editBtn);

	}	

	postDiv.append(authorDiv);
	postDiv.append(contentDiv);
	postDiv.append(likesDiv);
	postDiv.append(dislikesDiv);
	postDiv.append(commentsDiv);

	document.querySelector("#posts").prepend(postDiv);

	updateLikes(uniqid);

	// event listeners for like and dislike

	//	LIKE FUNCTION

	likesIcon.addEventListener("click", function(){

		var post_id = this.getAttribute("data-like");


		if(this.classList.contains("far")){

			if(dislikesIcon.classList.contains("fas")){

				dislikesIcon.classList.remove("fas");
				dislikesIcon.classList.add("far");
			}


			var action = "like";
			this.classList.remove("far");
			this.classList.add("fas");

		}
		else{

	
			var action = "unlike";
			this.classList.remove("fas");
			this.classList.add("far");
		}

		
		var xhr = new XMLHttpRequest();

		xhr.open("GET", "posts/like-posts.php?post_id="+post_id+"&username="+session_un+"&action="+action, true);

		xhr.send();

		setTimeout(function(){updateLikes(post_id)}, 100);


	})


	//	DISLIKE FUNCTION

	dislikesIcon.addEventListener("click", function(){

		var post_id = this.getAttribute("data-dislike");

		if(this.classList.contains("far")){

			if(likesIcon.classList.contains("fas")){

				likesIcon.classList.remove("fas");
				likesIcon.classList.add("far");
			}

			var action = "dislike";
			this.classList.remove("far");
			this.classList.add("fas");

		}
		else{

			var action = "unlike";
			this.classList.remove("fas");
			this.classList.add("far");
		}

		var xhr = new XMLHttpRequest();

		xhr.open("GET", "posts/like-posts.php?post_id="+post_id+"&username="+session_un+"&action="+action, true);

		xhr.send();

		setTimeout(function(){updateLikes(post_id)}, 100);

	})

	// COMMENT FUNCTION

	commentsIcon.addEventListener("click", function(){

		window.location="comment.php?uniqid="+uniqid+"&topic="+topic+"&author="+author+"&content="+content;
	})

	isLiked(uniqid);

}

function isLiked(uniqid){

	//console.log("hi");

	var params = "uniqid="+uniqid+"&username="+session_un;
	
	var xhr = new XMLHttpRequest();	

	xhr.open("POST", "posts/isliked-posts.php", true);

	xhr.setRequestHeader('Content-type', 'application/x-www-form-urlencoded');

	xhr.onload = function(){

		if(this.status==200){

			var status = this.responseText;

			switch(status){

				case "0": 
					break;
				case"1": var icon = document.querySelector("#likes-"+uniqid);
						icon.classList.remove("far");
						icon.classList.add("fas");
						break;
				case "-1": var icon = document.querySelector("#dislikes-"+uniqid);
						icon.classList.remove("far");
						icon.classList.add("fas");
						break;
						
			}
		}
	}

	xhr.send(params);

}

function updateLikes(post_id){


	var xhr = new XMLHttpRequest();
	xhr.open('GET', 'posts/updatelikes-posts.php?post_id='+post_id, true);

	xhr.onload = function(){

		if(this.status == 200){

			var result = JSON.parse(this.responseText);

			var likes = 0;
			var dislikes = 0;

			for(var i in result){				

				if(result[i].like_status ==1) likes++;

				else if(result[i].like_status==-1) dislikes++;

			}

			var likesSpan = document.querySelector("#likes-count-"+post_id);
			var dislikesSpan = document.querySelector("#dislikes-count-"+post_id);

			likesSpan.innerHTML = likes;
			dislikesSpan.innerHTML = dislikes;
			
		}

	}

	xhr.send();

}


function updateComments(uniqid){

	var xhr = new XMLHttpRequest();

			var params = "uniqid="+uniqid;	

			xhr.open("POST", "posts/display-cmt.php", true);

			xhr.setRequestHeader('Content-type', 'application/x-www-form-urlencoded');

			xhr.onload = function(){

				if (this.status==200){

					var comments = JSON.parse(this.responseText);

					document.querySelector("#comments-count-"+uniqid).innerHTML = comments.length;
					

				}

			}

			

		xhr.send(params);


}

// edit form functions with e.f buttons


var editSubmit = document.querySelector("#edit-submit");
var editDiscard = document.querySelector("#edit-discard");
var editForm = document.querySelector(".edit-form");


editDiscard.addEventListener("click", discardEdit);

function discardEdit(){

	document.querySelector(".edit-form-topic").value = "";
	document.querySelector(".edit-form-content").value = "";
	editForm.style.visibility = "hidden";
}

function showEditForm(uniqid){

	editForm.style.visibility= "visible";

	// setting the values in the form

	document.querySelector(".edit-form-topic").value = document.querySelector("#topic-"+uniqid).innerHTML;
	document.querySelector(".edit-form-content").value = document.querySelector("#content-"+uniqid).innerHTML;
	document.querySelector(".edit-form-uniqid").value = uniqid;

}

//when you click submit on the edit form

editSubmit.addEventListener("click", editPost);

function editPost(){


	if(document.querySelector(".edit-form-content").value=="" || document.querySelector(".edit-form-topic").value==""){

		alert("Please fill out all fields");
		return;
	}

	var uniqid = document.querySelector(".edit-form-uniqid").value;
	var topic = document.querySelector(".edit-form-topic").value
	var content = document.querySelector(".edit-form-content").value

	var params = "content="+content+"&topic="+topic+"&uniqid="+uniqid;

	var xhr = new XMLHttpRequest();
	xhr.open("POST", "posts/edit-posts.php", true);
	xhr.setRequestHeader('Content-type', 'application/x-www-form-urlencoded');

	xhr.send(params);

	setTimeout(function(){ updatePost(uniqid)}, 100);

	discardEdit();
}


function updatePost(uniqid){

	var xhr = new XMLHttpRequest();

			var params = "uniqid="+uniqid;	

			xhr.open("POST", "posts/update-posts.php", true);

			xhr.setRequestHeader('Content-type', 'application/x-www-form-urlencoded');

			xhr.onload = function(){

				if (this.status==200){

					var post = JSON.parse(this.responseText);

					document.querySelector("#topic-"+uniqid).innerHTML = post[0].topic;
					document.querySelector("#content-"+uniqid).innerHTML = post[0].content;
					

				}

			}

			

		xhr.send(params);

		discardEdit();
}

//when you click the delete button on the edit form

function deletePost(uniqid){

	if(confirm("Are you sure you want to delete this post?")){

		var params = "uniqid="+uniqid;

		var xhr = new XMLHttpRequest();
		xhr.open("POST", "posts/delete-posts.php", true);
		xhr.setRequestHeader('Content-type', 'application/x-www-form-urlencoded');


		xhr.send(params);


		setTimeout(function(){

			document.querySelector("#posts").innerHTML="";
			displayAllPosts();

		}, 100);
;

	}

}