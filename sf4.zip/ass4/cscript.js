		console.log(usertype);

		window.onload=displayCmt(uniqid);

		var cmtBtn = document.querySelector("#cmt-btn");
		cmtBtn.addEventListener("click", function(){

			if(document.querySelector(".cmt-input").value==""){

				alert("Please fill out all fields");
				return;
			}

			var comment = document.querySelector(".cmt-input").value;

			var params = "commenter="+session_un+"&uniqid="+uniqid+"&comment="+comment;

			var xhr = new XMLHttpRequest();
			xhr.open("POST", "posts/submit-cmt.php", true);

			xhr.setRequestHeader('Content-type', 'application/x-www-form-urlencoded');

			xhr.send(params);


			setTimeout(function(){ displayCmt(uniqid)}, 100);

			document.querySelector(".cmt-input").value = "";

		})


		function displayCmt(uniqid){

			var xhr = new XMLHttpRequest();

			var params = "uniqid="+uniqid;	

			xhr.open("POST", "posts/display-cmt.php", true);

			xhr.setRequestHeader('Content-type', 'application/x-www-form-urlencoded');

			xhr.onload = function(){

				if (this.status==200){

					var comments = JSON.parse(this.responseText);

					document.querySelector(".comments").innerHTML = "";

					for(var i =comments.length-1; i>-1; i--){

						showCmt(comments[i].commenter, comments[i].comment, comments[i].cmt_uniqid);

					}

				}

			}

			

			xhr.send(params);


		}

	function showCmt(commenter, comment, cmt_uniqid){

		var cmtDiv = document.createElement("div");
		cmtDiv.className = "cmt-div";

		var cmtrDiv = document.createElement("div");
		cmtrDiv.className = "cmtr-div";

		var cmtBody = document.createElement("span");
		cmtBody.className = "cmt-body";
		cmtBody.id = "cmt-"+cmt_uniqid;

		//edit function

		var editSubmit = document.createElement("button");
		editSubmit.className = "edit-submit";
		editSubmit.id = "edit-"+cmt_uniqid;
		editSubmit.style.visibility = "hidden";
		editSubmit.innerHTML = "Submit";


		editSubmit.addEventListener("click", function(){

			editCmt(cmt_uniqid);

		})


		cmtrDiv.innerHTML = commenter;

		//option to edit or delete comment


		if(usertype=="admin" || commenter==session_un){


		var editBtn = document.createElement("i");
		var deleteBtn = document.createElement("i");

		editBtn.className="edit-btn far fa-edit";
		deleteBtn.className="delete-btn far fa-trash-alt";

		editBtn.addEventListener("click", function(){

			showEditCmt(cmt_uniqid);
		})

		deleteBtn.addEventListener("click", function(){

			deleteCmt(cmt_uniqid);
		})

		cmtDiv.append(deleteBtn);
		cmtDiv.append(editBtn);

	}	

		cmtBody.innerHTML = comment;

		cmtDiv.append(cmtrDiv);
		cmtDiv.append(cmtBody);
		cmtDiv.append(editSubmit);

		document.querySelector(".comments").append(cmtDiv);

	}


	//edit and delete functions

//DELETE FUNCTION

	function deleteCmt(cmt_uniqid){

		if(confirm("Are you sure you want to delete this comment?")){

		var params = "cmt_uniqid="+cmt_uniqid;

		var xhr = new XMLHttpRequest();
		xhr.open("POST", "posts/delete-cmt.php", true);
		xhr.setRequestHeader('Content-type', 'application/x-www-form-urlencoded');


		xhr.send(params);


		setTimeout(function(){

			document.querySelector(".comments").innerHTML="";
			displayCmt(uniqid);

		}, 100);


	}
	
}

// EDIT FUNCTION

function showEditCmt(cmt_uniqid){

	var cmt = document.querySelector("#cmt-"+cmt_uniqid);

	cmt.setAttribute("contenteditable", "true");
	cmt.style.outline = "1px solid #034158";
	cmt.style.padding = "1px";

	document.querySelector("#edit-"+cmt_uniqid).style.visibility = "visible";

	console.log("y");
}


function editCmt(cmt_uniqid){


	if(document.querySelector("#cmt-"+cmt_uniqid).innerHTML=="" ){

		alert("Please fill out the field");
		return;
	}

	var comment = document.querySelector("#cmt-"+cmt_uniqid).innerHTML;

	var params = "comment="+comment+"&cmt_uniqid="+cmt_uniqid;

	var xhr = new XMLHttpRequest();
	xhr.open("POST", "posts/edit-cmt.php", true);
	xhr.setRequestHeader('Content-type', 'application/x-www-form-urlencoded');

	xhr.onload = function(){

		if(this.status==200){

			console.log(this.responseText);
		}
	}

	xhr.send(params);

	setTimeout(function(){
				displayCmt(uniqid);

			}, 100);

	//document.querySelector("#edit-"+cmt_uniqid).style.visibility = "hidden";

}