<?php 
	
	session_start();
 ?>


<!DOCTYPE html>
<html>
	<head>
		<link rel="stylesheet" href="indexstyle.css">
		<script src="https://kit.fontawesome.com/8df63a29e3.js" crossorigin="anonymous"></script>
		<link href="https://fonts.googleapis.com/css2?family=Roboto+Mono&display=swap" rel="stylesheet">
	</head>

	<body>

		<?php 

			if(isset($_SESSION['username'])){

				header("Location: homepage.php");
				exit();
			}
		
		?>
	<header>
			<nav>
				<img class="main-logo" src="https://img.icons8.com/plasticine/80/000000/delete-chat--v2.png"/>
				<a class="homepage" href="index.php">forum.ppl</a>

			</nav>

			<?php 

			if(isset($_SESSION['username'])){
				
				echo "<form action='actions/logout-action.php'>
					<button type='submit
					' name='logout-btn' class='logout-btn'>LogOut</button>
					</form>";				;
			}

			?>



	</header>

	<div class="container">
			
		<form action="actions/login-action.php" method="post" class="login">

                <div class="form-heading">
                    <h1>Sign In!</h1>
                    <p>to share your thoughts with the world</p>
                </div>

				<input type="text" name="username" placeholder="Username">
				<input type="password" name="pwd" placeholder="Password">
			
				<input type="radio" class="radiobtn" name="usertype" value="user">
				<label class="radiolabel" for="user">User</label>

				<input type="radio" class="radiobtn" name="usertype" value="admin">
				<label class="radiolabel" for="admin">Admin</label><br>

				<button type="submit" name="login-submit">Sign In</button><br>

				<!-- <p>Dont have an account? Register by clicking below</p>

				<button type="button" onclick="location.href='reg.php'" name="reg-btn">Register</button> -->

				<div class="toggle">
                    <p id="tgl">^^</p>
					<div class="toggle-content">
						<p>Haven't registered yet?</p>
						<button id="reg-btn" type="button" onclick="location.href='reg.php'" name="reg-btn">Click here to sign up!</button>
						<i class="endicon fas fa-user-plus"></i>
					</div>
				</div>
			
		</form>

	</div>

		
		<script src="indexscript.js"></script>

	</body>
</html>

