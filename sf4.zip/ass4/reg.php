<?php 
	
	session_start();

 ?>

<!DOCTYPE html>
<html>
	<head>
		<link rel="stylesheet" href="regstyle.css">
		<link href="https://fonts.googleapis.com/css2?family=Roboto+Mono&display=swap" rel="stylesheet">
	</head>

	<body>

	<header>
			<nav>
				<img class="main-logo" src="https://img.icons8.com/plasticine/80/000000/delete-chat--v2.png"/>
				<a class="homepage" href="index.php">forum.ppl</a>

			</nav>

			<?php 

			if(isset($_SESSION['username'])){
				
				echo "<form action='actions/logout-action.php'>
					<button type='submit
					' name='logout-btn' class='logout-btn'>LogOut</button>
					</form>";	
			}

			?>



		</header>

	<div class="container">
			
			<form action="actions/reg-action.php" class="login" method="post">

				<div class="form-header">
					<h1>Welcome!<br>Register as a New User</h1>
					<p>enter your details below:</p>
				</div>

				<input type="text" name="fname" placeholder="First Name"><br>
				<input type="text" name="lname" placeholder="Last Name"><br>
				<input type="text" name="username" placeholder="Username"><br>
				<input type="text" name="email" placeholder="Email Address"><br>
				<input type="password" name="pwd" placeholder="Choose Password"><br>
				<input type="password" name="pwdConfirm" placeholder="Confirm Password"><br>

				<label for="dob" class="lbl-hdr">Date of Birth: </label>
				<input type="date" name="dob"><br>
		
				<label class="lbl-hdr">Gender: </label>
				<span>
				<input type="radio" class="radiobtn" name="gender" value="m">
				<label class="lbl" for="m">Male</label>
				</span>
				<span>
				<input type="radio" class="radiobtn" name="gender" value="f">
				<label class="lbl" for="f">Female</label>
				</span>
				<span>
				<input type="radio" class="radiobtn" name="gender" value="nb">
				<label class="lbl" for="nb">Non-binary</label><br>
				</span>

				<label class="lbl-hdr">Type of account: </label>
				<span>
				<input type="radio" class="radiobtn" name="usertype" value="user">
				<label class="lbl" for="user">User</label>
				</span>

				<span>
				<input type="radio" class="radiobtn" name="usertype" value="admin">
				<label class="lbl" for="admin">Admin</label><br><br>
				</span>
				
				<button type="submit" name="reg-submit">Register</button>
				
			</form>
		</div>
	</body>
</html>